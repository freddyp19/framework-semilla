<?php session_start();
/*
Código necesario para la ejecución
*/

 	include("../../inc/config.sistema.php");
						require_once("../../modelo/config.modelo.php"); # configuracion del modelo		
							require_once("../../modelo/class_tbl_estatus_usuarios.php"); # clase del modelo
		$Obj_tbl_estatus_usuarios = new tbl_estatus_usuarios;	require_once("../../modelo/class_tbl_perfiles.php"); # clase del modelo
		$Obj_tbl_perfiles = new tbl_perfiles;	require_once("../../modelo/class_tbl_regiones.php"); # clase del modelo
		$Obj_tbl_regiones = new tbl_regiones;
					
					$_SESSION["where"]="";	
			
?>
<?php	include(RUTA_SISTEMA."/vista/layouts/{$defaul_layouts}/header_autenticacion.php"); ?>
		<!--inicio viata de plantilla -->
		
		
		<script type="text/javascript" src="../../js/validaciones/autenticar.js"></script><!--
		<div id="div_respuesta" align="center"></div><br>
		
		<div id="panel">
		<a href="formulario.php?accion=insertar" class="boton">Insertar</a>
		<a href="formulario.php?accion=buscar" class="boton">Buscar</a>
		<a href="listar.php" class="boton">Listar</a>

		</div>
		 -->

		<form id="frm_formulario" name="frm_formulario"> <!--  method="post" action="javascript:void(null);" onSubmit="return validar_tbl_usuarios(this);" -->
		
		<input name="accion" id="accion" type="hidden" value="<?php echo $_REQUEST["accion"]="autenticar"?>" />
		<input name="quien" id="quien" type="hidden" value="<?php echo $_REQUEST["quien"]?>" />
	<table cellpadding="0" cellspacing="0" class="grupoCampos" align="center">
				  <tr>
					<td colspan="2" class="tituloGrupoCampos"><?php echo strtoupper($_REQUEST["accion"]); ?> - Usuarios </td>
				  </tr>
				<tr>
					<td class="tituloCelda">usuario</td>
					<td>	<input name="usuario" id="usuario" type="text" class="text_campos" maxlength="50" value="<?php echo $_REQUEST["usuario"]; ?>" title="insertar usuario" />*

					</td>
			  	</tr>
				<tr>
					<td class="tituloCelda">clave</td>
					<td>	<input name="clave" id="clave" type="password" class="text_campos" maxlength="15" value="<?php echo $_REQUEST["clave"]; ?>" title="insertar clave" />*

					</td>
			  	</tr>		
		  <tr>
			<td colspan="2" class="pieGrupoCampos">
			<input name="" type="submit" value="<?php echo strtoupper($_REQUEST["accion"]); ?>" class="boton" />
			<input name="" type="reset" value="Cancelar" class="boton" />
			</td>
		  </tr>
		</table>
	</form>
	
		
		<!--fin viata de plantilla -->
<?php include(RUTA_SISTEMA."/vista/layouts/{$defaul_layouts}/footer.php"); ?>