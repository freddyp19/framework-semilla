<?php
	session_start();
	require_once("../inc/config.sistema.php"); # configuracion del sistema
	require_once("../modelo/config.modelo.php"); # configuracion del modelo
	require_once("../modelo/class_tbl_usuarios.php"); # clase del modelo
	$Obj_tbl_usuarios = new tbl_usuarios($_REQUEST["cedula"],$_REQUEST["usuario"],$_REQUEST["clave"],$_REQUEST["nombres"],$_REQUEST["apellidos"],$_REQUEST["correo_electronico"],$_REQUEST["id_estatu_usuario"],$_REQUEST["id_perfil"],$_REQUEST["id_region"]);
		
	switch ($_REQUEST["accion"])
	{
		case "buscar":
			$_SESSION["where"]="";	
			if ($Obj_tbl_usuarios->buscar())
			{
				$retorna["mensaje"]="se agrego el registro a la Base de Datos"; 
				$retorna["datos"]="";
				$retorna["estado"]="encontrado"; 
			}
			else
			{ 
			
				$retorna["mensaje"]="NO se encuentra registro";
				$retorna["datos"]="";
				$retorna["estado"]="no_encontrado";
			}
			echo json_encode($retorna);
		break;
		
		case "insertar":
			$insertado=$Obj_tbl_usuarios->insertar();
			if (is_numeric($insertado))
			{  
			$retorna["mensaje"]="se agrego el registro a la Base de Datos"; 
			$retorna["datos"]="";
			$retorna["estado"]="insertado";
			}
			else
			{ 
			$retorna["mensaje"]=$insertado;//"NO se agrego el registro a la Base de Datos";
			$retorna["datos"]="";
			$retorna["estado"]="false";
			}
			echo json_encode($retorna);

		break;
		
		case "actualizar":
			$actualizado=$Obj_tbl_usuarios->actualizar();
			if (is_numeric($actualizado))
			{  
				$retorna["mensaje"]="se actualizo..."; 
				$retorna["datos"]="";
				$retorna["estado"]="actualizado";
			}
			else
			{ 
				$retorna["mensaje"]="NO se actualizo ".$actualizado;//"NO se agrego el registro a la Base de Datos";
				$retorna["datos"]="";
				$retorna["estado"]="false";
			}
			echo json_encode($retorna); 
		break;
		
		case "eliminar":
		$Obj_tbl_usuarios->where=" USUARIO = '".$_REQUEST["usuario"]."'";
		$eliminado=$Obj_tbl_usuarios->eliminar();
			if (is_numeric($eliminado))
			{  
				$retorna["mensaje"]="se elimino..."; 
				$retorna["datos"]="";
				$retorna["estado"]="eliminado";
			}
			else
			{ 
				$retorna["mensaje"]="No se elimino...".$eliminado;
				$retorna["datos"]="";
				$retorna["estado"]="false";
			}
			echo json_encode($retorna); 
		break;
		
		case "combo":
			
			$_SESSION["where"]="";	
			$combo=$Obj_tbl_usuarios->listar();
			$options=array();
			
			$options[0]["value"]="";
			$options[0]["text"]="Seleccione...";
			
				
			foreach($combo as $index => $valor)
			{
				$options[$index+1]["value"]=$valor["usuario"];
				$options[$index+1]["text"] =$valor["usuario"];
			}
			
			$retorna=$options;
			echo json_encode($retorna);
			 
		break;
		
		case "autenticar":
		$Obj_tbl_usuarios->where=" usuario = '".$_REQUEST["usuario"]."' and clave='".$Obj_tbl_usuarios->clave."'";
		$autenticado=$Obj_tbl_usuarios->listar(true);
		#echo "<pre>"; print_r($autenticado); exit;
			if (count($autenticado)==1)
			{  
				$_SESSION["session_usuario"]=$autenticado[0];
				$retorna["mensaje"]="Autenmticado el Usuario  [".$_REQUEST["usuario"]."]"; 
				$retorna["reenvio"]="../principal/index.php";
				$retorna["estado"]="autenticado";

			}
			else
			{ 
				$retorna["mensaje"]="No se encuentra el usuario [".$_REQUEST["usuario"]."]";
				$retorna["datos"]="";
				$retorna["estado"]="false";
			}
			echo json_encode($retorna); 
		break;
	}	
	
	?>
	