<?php session_start();
/*
Código necesario para la ejecución
*/


					include("../../../inc/config.sistema.php");
					require_once("../../../modelo/config.modelo.php"); # configuracion del modelo		
					
				
				$_SESSION["where"]="";	
			
?>
<?php	include(RUTA_SISTEMA."/vista/layouts/{$defaul_layouts}/header_autenticacion.php"); ?>
		

<table width="282" border="0" align="center" cellpadding="2" cellspacing="2">
									<tr>
                                    	<td width="124" style="vertical-align:middle; font-family:Arial; font-size:12px; color:#999999;">		
				<h5 style="padding:0px; margin-bottom:0px; text-align:left;">
          <font size="3" face="verdana, arial, sans-serif" color="#696969"><?php echo $nombresistema ?>
											</font>
                                            <br><br>
                                           <!-- <font size="2" color="#696969"><?php echo strtoupper($direccionsistema)?></font> -->
                                            </h5>
										</td>
									</tr>
								</table>

							</div>
							
							<script type="text/javascript" src="/<?php echo $sistema; ?>/js/validaciones/schema_usuarios/autenticar_LDAP.js"></script>
							
							<form id="frm_formulario" name="frm_formulario"> 
								<input name="accion" id="accion" type="hidden" value="<?php echo $_REQUEST["accion"]="autenticar_LDAP"; ?>" />
								<input name="quien" type="hidden" value="<?php echo $_REQUEST["quien"]?>" />
								<table cellpadding="0" cellspacing="0" class="grupoCampos" align="center">
									<tr>
										<td colspan="2" class="tituloGrupoCampos">
											<?php echo strtoupper($_REQUEST["accion"]); ?> - Usuarios 
										</td>
									</tr>
									<tr>
										<td class="tituloCelda">Usuario
										</td>
										<td>	
     <input name="usuario" id="usuario" type="text" class="text_campos" maxlength="15" value="<?php echo $_REQUEST["usuario"]; ?>" />*
										</td>
									</tr>
									<tr>
										<td class="tituloCelda">Clave
										</td>
										<td>	
	<input name="clave" id="clave" type="password" class="text_campos" maxlength="15" value="<?php echo $_REQUEST["clave"]; ?>" />*
										</td>
									</tr>
									<tr>
										<td colspan="2" class="pieGrupoCampos">
				<input type="submit" value="Autenticar" class="boton" />
				<input name="" type="reset" value="Cancelar" class="boton" />
										</td>
									</tr>
								</table>
							</form>
							<br>
								<div id="div_respuesta" align="center"><!--AQUI VA EL MENSAJE DE RESPUESTA-->
								</div>
							<br>
						</td>
						<td width="1">
						</td>
						<td valign="top" class="style15" height="350px">
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td>
			<img src="/<?php echo $sistema; ?>/vista/layouts/<?php echo $defaul_layouts; ?>/imagenes/imagenes.gif">
									</td>
								</tr>
							</table>
							<?php include(RUTA_SISTEMA."/vista/layouts/{$defaul_layouts}/footer.php"); ?>

							
							<!--
						</td>
					</tr>
				</table>
			</div>
		</td>
	</tr>
	
	
	<!--fin cuarta fila-->
	
	<!--
</table>-->
	