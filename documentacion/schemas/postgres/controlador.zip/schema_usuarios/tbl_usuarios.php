<?php
	session_start();

	require_once("../../inc/config.sistema.php"); # configuracion del sistema
	require_once("../../modelo/config.modelo.php"); # configuracion del modelo
	require_once("../../modelo/schema_usuarios/class_tbl_usuarios.php"); # clase del modelo
	$Obj_tbl_usuarios = new tbl_usuarios($_REQUEST["cedula"],$_REQUEST["nombres"],$_REQUEST["apellidos"],$_REQUEST["correo_electronico"],$_REQUEST["usuario"],$_REQUEST["clave"],$_REQUEST["id_estatu_usuario"],$_REQUEST["id_perfil"],$_REQUEST["id_region"]);
		
	switch ($_REQUEST["accion"])
	{
		case "buscar":
			$_SESSION["where"]="";	
			if ($Obj_tbl_usuarios->buscar())
			{
				$retorna["mensaje"]="se agrego el registro a la Base de Datos"; 
				$retorna["datos"]="";
				$retorna["estado"]="encontrado"; 
			}
			else
			{ 
			
				$retorna["mensaje"]="NO se encuentra registro";
				$retorna["datos"]="";
				$retorna["estado"]="no_encontrado";
			}
			echo json_encode($retorna);
		break;
		
		case "insertar":
		
			$insertado=$Obj_tbl_usuarios->insertar();
			if ($insertado)
			{  
			$retorna["mensaje"]="se agrego el registro a la Base de Datos"; 
			$retorna["datos"]="";
			$retorna["estado"]="insertado";
			}
			else
			{ 
			$retorna["mensaje"]="NO se agrego el registro a la Base de Datos";
			$retorna["datos"]="";
			$retorna["estado"]="false";
			}
			echo json_encode($retorna);

		break;
		
		case "actualizar":
			$actualizado=$Obj_tbl_usuarios->actualizar();
			if (is_numeric($actualizado))
			{  
				$retorna["mensaje"]="se actualizo..."; 
				$retorna["datos"]="";
				$retorna["estado"]="actualizado";
			}
			else
			{ 
				$retorna["mensaje"]="NO se actualizo ";//"NO se agrego el registro a la Base de Datos";
				$retorna["datos"]="";
				$retorna["estado"]="false";
			}
			echo json_encode($retorna); 
		break;
		
		case "eliminar":
		$Obj_tbl_usuarios->where=" usuario = '".$_REQUEST["usuario"]."'";
		$eliminado=$Obj_tbl_usuarios->eliminar();
			if (is_numeric($eliminado))
			{  
				$retorna["mensaje"]="se elimino..."; 
				$retorna["datos"]="";
				$retorna["estado"]="eliminado";
			}
			else
			{ 
				$retorna["mensaje"]="No se elimino...";
				$retorna["datos"]="";
				$retorna["estado"]="false";
			}
			echo json_encode($retorna); 
		break;
		
		case "combo":
			
			$_SESSION["where"]="";	
			$combo=$Obj_tbl_usuarios->listar();
			$options=array();
			
			$options[0]["value"]="";
			$options[0]["text"]="Seleccione...";
			
				
			foreach($combo as $index => $valor)
			{
				$options[$index+1]["value"]=$valor[""];
				$options[$index+1]["text"] =$valor[""];
			}
			
			$retorna=$options;
			echo json_encode($retorna);
			 
		break;
		
		case "autenticar_LDAP":
		
		//	$Obj_tbl_usuarios->clave=$_REQUEST["clave"];
	
			$usuario_ldap=$Obj_tbl_usuarios->autenticar_usuario_ldap();
			
			//echo "<pre>"; print_r ($usuario_ldap); exit;
				
			if (is_array($usuario_ldap))
			{
			
				$Obj_tbl_usuarios->where=" usuario = '".$_REQUEST["usuario"]."'";
				$usuario_bd=$Obj_tbl_usuarios->listar(true);
	
	//echo "<pre>"; print_r ($usuario_bd); exit;
				if(count($usuario_bd)==1){	
						
					$_SESSION['session_usuario']=$usuario_bd[0];
					$_SESSION["session_usuario"]["nombre_completo"]=$usuario_bd[0]["nombres"]." ".$usuario_bd[0]["apellidos"];
					$retorna["mensaje"]="Usuario Autenticado"; 
					$retorna["estado"]="autenticado";
					$retorna["reenvio"]="../../principal/index/";				
				}
				else
				{
					$retorna["mensaje"]=" usuario no cuenta con perfiles en el sistema ";
					$retorna["estado"]="no_autenticado";
				}
			}
			else
			{ 
				$retorna["mensaje"]=$usuario_ldap;
				$retorna["estado"]="no_autenticado";
			}
			
			echo json_encode($retorna); 		

		break;
		
		case "autenticar_base_datos":
		
		//	$Obj_tbl_usuarios->clave=$_REQUEST["clave"];
	
			$Obj_tbl_usuarios->where=" usuario='".$Obj_tbl_usuarios->usuario."' and clave='".$Obj_tbl_usuarios->clave."'";
			$usuarios=$Obj_tbl_usuarios->listar(true);
			 
			if (count($usuarios)==1)
			{
			
				$Obj_tbl_usuarios->where=" cedula = '".$usuarios[0]["cedula"]."'";
				$usuario_bd=$Obj_tbl_usuarios->listar(true);
	
				if(count($usuario_bd)==1){	
						
					$_SESSION['session_usuario']=$usuario_bd[0];
					$_SESSION["session_usuario"]["nombre_completo"]=$usuario_bd[0]["nombres"]." ".$usuario_bd[0]["apellidos"];
					$retorna["mensaje"]="Usuario Autenticado"; 
					$retorna["estado"]="autenticado";
					$retorna["reenvio"]="../../principal/index/";				
				}
				else
				{
					$retorna["mensaje"]=" usuario no cuenta con perfiles en el sistema ";
					$retorna["estado"]="no_autenticado";
				}
			}
			else
			{ 
				$retorna["mensaje"]="El usuario no se encuentra en base de datos";
				$retorna["estado"]="no_autenticado";
			}
			
			echo json_encode($retorna); 		

		break;

			
/* Autenticar en la base de datos (verifico si este usuario esta registrado en el sistema)*/ 

		case "autenticar":

			$Obj_tbl_usuarios->where="usuario='".$_REQUEST["usuario"]."'";
			$registros=$Obj_tbl_usuarios->listar(true);
			if (count($registros)==1)
			{
				$id_usuario=$registros[0]["id_usuario"];
				$nombre_completo_usuario=$registros[0]["nombres"]." ".$registros[0]["apellidos"];
				$cedula=$usuario["cedula"];	
				$retorna["mensaje"]="autenticado [".$usuario["nombre_completo"]."]";
					$retorna["datos"]="";
					$_SESSION['session_usuario']['usuario']=$_REQUEST["usuario"];				
					$_SESSION['session_usuario']['id_perfil']=$id_perfil;
					$_SESSION['session_usuario']['id_usuario']=$id_usuario;
					$_SESSION['session_usuario']['nombre_completo']=$nombre_completo_usuario;
					$retorna["estado"]="autenticado";
					$retorna["cedula"]=$cedula;
					$retorna["reenvio"]="../principal";
			}
			else
			{ 
				$retorna["mensaje"]="El usuario [".$_REQUEST["usuario"]."] no esta autorizado para ingresar al sistema";
				$retorna["datos"]="";
				$retorna["estado"]="no_encontrado";
			}
	
			echo json_encode($retorna); 		
		break; 
	 
	 }
	
	?>
	