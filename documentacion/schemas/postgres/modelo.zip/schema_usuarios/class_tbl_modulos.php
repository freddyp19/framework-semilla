<?php session_start();
	
class tbl_modulos extends general {

	public $bd;
	public $campos="*";
	public $where;
	private $ObjetSQL;
	public $tabla;
	private $propiedades = array();

	public function __construct($id_modulo=NULL,$modulo=NULL,$descripcion_modulo=NULL,$posicion_modulo=NULL) {

		$main = main::getInstance();
		$MotorSQL = $main->motor."_sql";
		include_once(MODELO."abstraccion".DS."db".DS."{$main->motor}-sql.lang.php");
		$this->ObjetSQL = new $MotorSQL();
		//$this->bd = new db();
		  $this->bd = db::getInstance();

		$this->propiedades["id_modulo"]=$id_modulo;
		$this->propiedades["modulo"]=$modulo;
		$this->propiedades["descripcion_modulo"]=$descripcion_modulo;
		$this->propiedades["posicion_modulo"]=$posicion_modulo;
		$this->where=" id_modulo = ".$this->bd->qstr($this->propiedades["id_modulo"]);
		$this->tabla="schema_usuarios.tbl_modulos";
		}

	public function __set($nombre, $valor) {
		$this->propiedades[$nombre] = $valor;
	}

	public function __get($nombre) {
		return $this->propiedades[$nombre];
	}

    public function __call($metodo, $args) {
       	if ($args) {
       		 $method = array(&$this->bd, $metodo);
       		 $a = call_user_func_array($method, $args);
       	} else {
       		$a = $this->bd->$metodo();
       	}
    	return $a;
	}
	public function insertar(){
		try {
		#array_shift($this->propiedades);
			$retorno=$this->id_modulo=$this->GenID('schema_usuarios.tbl_modulos_id_modulo_seq');
			$record=$this->AutoExecute($this->tabla,$this->propiedades,'INSERT');

			
		} catch (exception $e) {
			$retorno=$this->ErrorMsg();
		}
	return $retorno;
	}
	public function actualizar(){
		try {
			$record=$this->AutoExecute($this->tabla,$this->propiedades,'UPDATE',$this->where);
			if ($record){
				$retorno=$this->id_modulo;
			}
			else{
				$retorno=false;
			}
		} catch (exception $e) {
			$retorno=$this->ErrorMsg();
		}
	return $retorno;
	}

	public function eliminar(){
	
		$ObjetSQL=&$this->ObjetSQL;
		
		$sql.=sprintf($ObjetSQL->delete,$this->tabla);
		
		$sql.=sprintf($ObjetSQL->where,$this->where);

		try {	
			$record=$this->Execute($sql);
			if ($record){
				$retorno=1;
			}
			else{
				$retorno=false;
			}
		} catch (exception $e) {
			$retorno=$this->ErrorMsg();
		}	
	return $retorno;
	}

	public function listar($campos=false){

		$ObjetSQL=&$this->ObjetSQL;

		$this->tabla_l=$this->tabla;
		$sql.=sprintf($ObjetSQL->select,$this->campos,$this->tabla_l);

		if ($campos){
			$sql.=sprintf($ObjetSQL->where,$this->where);
		}
		$sql.=$this->v_limit;
		//echo $sql; exit;
		$record = $this->Execute($sql);

		if ($record){
			$retorno=$record->GetRows();
		}
		else{
			$retorno=false;
		}

		return $retorno;
	}


	public function total_registros(){
	
		$ObjetSQL=&$this->ObjetSQL;
		
		$this->campos_t=" count(*) as total_registros ";
		
		$sql=sprintf($ObjetSQL->select,$this->campos_t,$this->tabla);
		
		if($this->where){
		$sql.=sprintf($ObjetSQL->where,$this->where);
		}
		
		//$sql="select count(*) as total_registros from ".$this->tabla." where ".$this->where; 					
		//sprintf($ObjetSQL->delete,$this->tabla);
		
		//$sql.=sprintf($ObjetSQL->where,$this->where);

		try {	
			$record = $this->Execute($sql);

			if ($record){
				$retorno=$record->GetRows();
				$retorno=$retorno[0]["total_registros"];
				
			}
			else{
				$retorno=false;
			}
		} catch (exception $e) {
			$retorno=$this->ErrorMsg();
		}	
	return $retorno;
	}
	
	public function limit($inicio,$fin){

		$ObjetSQL=&$this->ObjetSQL;
		
		if ($_SESSION["where"]!="") {$sql=true;} else {$sql=false;}

		$this->v_limit=sprintf($ObjetSQL->limit,$inicio,$fin);
		
		//echo $sql; exit;
		
		$retorno = $this->listar($sql);

		return $retorno;
	}
    public function buscar($campos=true){

		if (($campos) && ($_SESSION["where"]=="")) {
			$no_buscar = array("id_usuario","usuario","computadora","fecha_hora_sis");
			foreach ($this->propiedades as $key => $valor)
			{
				if(($valor) && !(in_array($key, $no_buscar)))
				{
				
					if (substr_count($key,"id_"))
					{
					$where.="$key in ($valor) AND ";
					}
					else
					{
					$where.="$key LIKE'%$valor%' AND ";
					}
					
				}
			}
			$where.="false";
			$where=str_replace(" AND false","",$where);
			$this->where=$where;
			$_SESSION["where"]=$this->where;
		}
		else
		{
			$this->where=$_SESSION["where"];
		}

		//echo $this->where; exit;

		$retorno = $this->listar(true);
		return $retorno;
	}
	public function ver_opciones($ver=NULL)
	{

		$campos=$this->listar();

		if ($campos) {

			foreach($campos as $index => $valor)
			{

				if ($valor["id_modulo"]==$ver)
				{
				$option.="<option value='".$valor["id_modulo"]."' selected>".$valor["modulo"]."</option>";
				}
				else
				{
				$option.="<option value='".$valor["id_modulo"]."' >".$valor["modulo"]."</option>";
				}
			}
		}
		else {$option = false;}

		return $option;

	}


	public function ver_checkbox_tbl_modulos($buscado)
	{

		$campos=$this->listar();

		if ($campos) {

			foreach($campos as $index => $valor)
			{
				if (in_array($valor["id_modulo"], $buscado))
				{
				$option.="<input type='checkbox' value='".$valor["id_modulo"]."' checked='checked' />".$valor["modulo"]."<br />";
				}
				else
				{
				$option.="<input type='checkbox' value='".$valor["id_modulo"]."' />".$valor["modulo"]."<br />";
				}
			}
		}
		else {$option = false;}

		return $option;

	}


	public function valor_campo($campo)
	{
		$campos=$this->listar(true);
		return $campos[0][$campo];
	}


} //fin de la clase tbl_modulos
?>